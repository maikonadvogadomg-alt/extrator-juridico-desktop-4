@echo off
title APK Builder
echo.
echo  ========================================
echo   APK Builder
echo  ========================================
echo.
echo  Iniciando servidor local...
echo.
python --version >nul 2>&1
if %errorlevel%==0 ( echo  Acesse: http://localhost:8081 && echo  CTRL+C para encerrar && start "" "http://localhost:8081" && python -m http.server 8081 && goto :end )
python3 --version >nul 2>&1
if %errorlevel%==0 ( echo  Acesse: http://localhost:8081 && echo  CTRL+C para encerrar && start "" "http://localhost:8081" && python3 -m http.server 8081 && goto :end )
echo  ERRO: Python nao encontrado. Instale em https://python.org
pause
:end
