#!/bin/bash
echo "  APK Builder"
echo "  Acesse: http://localhost:8081 — CTRL+C para encerrar"
(sleep 1 && (open "http://localhost:8081" 2>/dev/null || xdg-open "http://localhost:8081" 2>/dev/null)) &
if command -v python3 &>/dev/null; then python3 -m http.server 8081
elif command -v python &>/dev/null; then python -m http.server 8081
else echo "ERRO: instale Python em python.org"; exit 1; fi
