#!/bin/bash
echo ""
echo "  ========================================"
echo "   SK Code Editor"
echo "  ========================================"
echo ""
echo "  Iniciando servidor local..."
echo ""

if command -v python3 &>/dev/null; then
    echo "  Acesse: http://localhost:8082"
    echo "  Pressione CTRL+C para encerrar."
    echo ""
    (sleep 1 && (open "http://localhost:8082" 2>/dev/null || xdg-open "http://localhost:8082" 2>/dev/null)) &
    python3 -m http.server 8082
elif command -v python &>/dev/null; then
    echo "  Acesse: http://localhost:8082"
    echo "  Pressione CTRL+C para encerrar."
    echo ""
    (sleep 1 && (open "http://localhost:8082" 2>/dev/null || xdg-open "http://localhost:8082" 2>/dev/null)) &
    python -m http.server 8082
else
    echo "  ERRO: Python nao encontrado."
    echo "  Instale Python em https://python.org e tente novamente."
    exit 1
fi
