@echo off
title SK Code Editor
echo.
echo  ========================================
echo   SK Code Editor
echo  ========================================
echo.
echo  Iniciando servidor local...
echo.

python --version >nul 2>&1
if %errorlevel%==0 (
    echo  Acesse: http://localhost:8082
    echo  Pressione CTRL+C para encerrar.
    echo.
    start "" "http://localhost:8082"
    python -m http.server 8082
    goto :end
)

python3 --version >nul 2>&1
if %errorlevel%==0 (
    echo  Acesse: http://localhost:8082
    echo  Pressione CTRL+C para encerrar.
    echo.
    start "" "http://localhost:8082"
    python3 -m http.server 8082
    goto :end
)

echo  ERRO: Python nao encontrado.
echo  Instale Python em https://python.org e tente novamente.
echo.
pause
:end
