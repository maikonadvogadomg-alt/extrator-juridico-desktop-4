@echo off
title Iara - Assistente Juridico
echo.
echo  ========================================
echo   Iara - Assistente Juridico
echo  ========================================
echo.
echo  Iniciando servidor local...
echo.
python --version >nul 2>&1
if %errorlevel%==0 ( echo  Acesse: http://localhost:8080 && echo  CTRL+C para encerrar && start "" "http://localhost:8080" && python -m http.server 8080 && goto :end )
python3 --version >nul 2>&1
if %errorlevel%==0 ( echo  Acesse: http://localhost:8080 && echo  CTRL+C para encerrar && start "" "http://localhost:8080" && python3 -m http.server 8080 && goto :end )
echo  ERRO: Python nao encontrado. Instale em https://python.org
pause
:end
