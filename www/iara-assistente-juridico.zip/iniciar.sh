#!/bin/bash
echo "  Iara - Assistente Juridico"
echo "  Acesse: http://localhost:8080 — CTRL+C para encerrar"
(sleep 1 && (open "http://localhost:8080" 2>/dev/null || xdg-open "http://localhost:8080" 2>/dev/null)) &
if command -v python3 &>/dev/null; then python3 -m http.server 8080
elif command -v python &>/dev/null; then python -m http.server 8080
else echo "ERRO: instale Python em python.org"; exit 1; fi
